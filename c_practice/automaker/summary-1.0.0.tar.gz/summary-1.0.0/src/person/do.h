#ifndef _DO_H_
#define _DO_H_

void do_studied(void);
void do_done(void);
void do_can(void);
void do_need(void);

#endif /* _DO_H_ */
